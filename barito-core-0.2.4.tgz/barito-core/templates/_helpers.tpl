{{- define "barito-core.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "barito-core.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "barito-core.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "barito-core.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "barito-core.envTemplate" -}}
{{- $context := . }}
{{- range $key, $options := $context.config }}
- name: {{ $key }}
  {{- if get $options "secret" }}
  valueFrom:
    secretKeyRef:
      name: {{ $context.secretName }}
      key: {{ $key }}
  {{- else }}
  value: {{ tpl (toString $options.value) $context.root | quote }}
  {{- end }}
{{- end }}
{{- end }}

{{- define "barito-core.envTemplateSecretData" -}}
{{- $context := . }}
{{- range $key, $options := $context.config }}
{{- if get $options "secret" }}
{{ $key }}: {{ tpl (toString $options.value) $context.root | b64enc | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- define "barito-core.envTemplateSecretHash" -}}
{{- include "barito-core.envTemplateSecretData" . | sha256sum }}
{{- end }}
