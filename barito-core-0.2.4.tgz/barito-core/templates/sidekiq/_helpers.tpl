{{- define "barito-core.sidekiq.name" -}}
{{- $defaultValue := printf "%s-sidekiq" (include "barito-core.name" .) }}
{{- default $defaultValue .Values.sidekiq.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.sidekiq.fullname" -}}
{{- $defaultValue := printf "%s-sidekiq" (include "barito-core.fullname" .) }}
{{- default $defaultValue .Values.sidekiq.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.sidekiq.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.sidekiq.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.sidekiq.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.sidekiq.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
