{{- define "barito-core.viewer.name" -}}
{{- $defaultValue := printf "%s-viewer" (include "barito-core.name" .) }}
{{- default $defaultValue .Values.viewer.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.viewer.fullname" -}}
{{- $defaultValue := printf "%s-viewer" (include "barito-core.fullname" .) }}
{{- default $defaultValue .Values.viewer.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.viewer.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.viewer.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.viewer.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.viewer.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
