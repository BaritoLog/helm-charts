{{- define "barito-core.market.name" -}}
{{- $defaultValue := printf "%s-market" (include "barito-core.name" .) }}
{{- default $defaultValue .Values.market.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.market.fullname" -}}
{{- $defaultValue := printf "%s-market" (include "barito-core.fullname" .) }}
{{- default $defaultValue .Values.market.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.market.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.market.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.market.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.market.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
