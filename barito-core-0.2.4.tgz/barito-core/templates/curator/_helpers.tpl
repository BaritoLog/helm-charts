{{- define "barito-core.curator.name" -}}
{{- $defaultValue := printf "%s-curator" (include "barito-core.name" .) }}
{{- default $defaultValue .Values.curator.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.curator.fullname" -}}
{{- $defaultValue := printf "%s-curator" (include "barito-core.fullname" .) }}
{{- default $defaultValue .Values.curator.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.curator.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.curator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.curator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.curator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "barito-core.curator.clientKey" -}}
{{- if not .Values.config.curator.clientKey }}
{{- $key := printf "%s%s" (sha256sum (randAscii 32)) (sha256sum (randAscii 32)) }}
{{- $_ := set .Values.config.curator "clientKey" $key }}
{{- end }}
{{- .Values.config.curator.clientKey }}
{{- end }}
