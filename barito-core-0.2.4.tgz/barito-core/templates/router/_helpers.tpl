{{- define "barito-core.router.name" -}}
{{- $defaultValue := printf "%s-router" (include "barito-core.name" .) }}
{{- default $defaultValue .Values.router.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.router.fullname" -}}
{{- $defaultValue := printf "%s-router" (include "barito-core.fullname" .) }}
{{- default $defaultValue .Values.router.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "barito-core.router.labels" -}}
helm.sh/chart: {{ include "barito-core.chart" . }}
{{ include "barito-core.router.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "barito-core.router.selectorLabels" -}}
app.kubernetes.io/name: {{ include "barito-core.router.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
